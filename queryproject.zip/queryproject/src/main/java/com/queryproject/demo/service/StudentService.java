package com.queryproject.demo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.queryproject.demo.model.Student;
import com.queryproject.demo.repository.StudentRepository;

import jakarta.transaction.Transactional;

@Service
public class StudentService {
	@Autowired
	StudentRepository studRepository;
	public List<Student> getStudentsByDept(String dept,String name)
	  {
		  return studRepository.getStudentsByDept(dept, name);
	  }
	@Transactional 
	public int deleteStudentByName(String name)
	{
   	return studRepository.deleteStudentByName(name);
	}
	@Transactional
	public int updateStudentByName(String dept,String name)
	{
		return studRepository.updateStudentByName(dept, name);
	}
public List<Student> getStudentsByDept(String dept) {
		
		return studRepository.getStudentsByDept(dept) ;
	}
	

}